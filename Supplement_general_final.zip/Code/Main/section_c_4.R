# Seeding
set.seed(1729)

# Loading the functions file
source("./Functions/Functions.R")

# Libraries
library(ggplot2)
library(dplyr)
library(viridis)
library(grid)
library(gridExtra)
library(latex2exp)

# Defining necessary parameters
n <- 10^4
period <- 3
cos.sched <- 1 + cos(2*pi*my.seq/period)
my.seq <- seq(n)
beta.505 <- my.seq^(-0.505)
beta.75 <- my.seq^(-0.75)
low.odd <- beta.505[seq(1, n, 2)]
high.even <- beta.75[seq(2, n, 2)]
mix.low.high <- as.vector(rbind(low.odd, high.even))
lin.sched <- rev(my.seq)/n
theta.init <- c(0, 0)
theta.true <- c(2, -3)

# SGD runs for learning rates being compared
thetas.0.05 <- sgd.lr.sched.multiple(num.iterations, theta.0, theta.true, sd=1, rep(0.05, n))
thetas.cos.0.05 <- sgd.lr.sched.multiple(num.iterations, theta.0, theta.true, sd=1, 0.05*cos.sched)
thetas.0.1.0.505 <- sgd.lr.sched.multiple(num.iterations, theta.0, theta.true, sd=1, 0.1*beta.505)
thetas.0.1.low.high <- sgd.lr.sched.multiple(num.iterations, theta.0, theta.true, sd=1, 0.1*mix.low.high)
thetas.lin.0.1 <- sgd.lr.sched.multiple(num.iterations, theta.0, theta.true, sd=1, 0.1*lin.sched)

# Calculating the MSE and SE SD for the SGD runs
mse.se.sd.0.05 <- calculate.mse.se.sd(thetas.0.05, theta.true)
mse.se.sd.cos.0.05 <- calculate.mse.se.sd(thetas.cos.0.05, theta.true)
mse.se.sd.0.1.0.505.cos <- calculate.mse.se.sd(thetas.0.1.0.505, theta.true)
mse.se.sd.0.1.low.high <- calculate.mse.se.sd(thetas.0.1.low.high, theta.true)
mse.se.sd.lin.0.1 <- calculate.mse.se.sd(thetas.lin.0.1, theta.true)

# Comparison list
comparison_list <- list(
  list(data = calculate.mse.se.sd(thetas.0.05, theta.true), label = "Constant η = 0.05"),
  list(data = calculate.mse.se.sd(thetas.cos.0.05, theta.true), label = "Cosine η₀ = 0.05"),
  list(data = calculate.mse.se.sd(thetas.0.1.0.505, theta.true), label = "Polynomial η₀ = 0.1, β = 0.505"),
  list(data = calculate.mse.se.sd(thetas.0.1.low.high, theta.true), label = "Alternating polynomial η₀ = 0.1, β = (0.505, 0.75)"),
  list(data = calculate.mse.se.sd(thetas.lin.0.1, theta.true), label = "Linear-D2Z η₀ = 0.1")
)

# Use external helper function to construct data frame
df_comparison <- do.call(rbind, lapply(comparison_list, function(x)
  create_plot_data(x$data, x$label)))

# Split into three iteration ranges
df_1 <- df_comparison %>% filter(iteration >= 1, iteration <= 100)
df_2 <- df_comparison %>% filter(iteration > 100, iteration <= 9900)
df_3 <- df_comparison %>% filter(iteration > 9900)

# Color palette
labels <- unique(df_comparison$label)
colors <- viridis(length(labels), option = "turbo")
names(colors) <- labels

# Create legend manually
legend_data <- data.frame(x = rep(1, length(labels)), y = 1:length(labels), label = labels)
legend_plot <- ggplot(legend_data, aes(x = x, y = y, color = label)) +
  geom_point(size = 3) +
  scale_color_manual(
    values = colors,
    name = "Schedule",
    breaks = labels,
    guide = guide_legend(ncol = 3)
  ) +
  theme_void() +
  theme(
    legend.position = "bottom",
    legend.text = element_text(size = 9),
    legend.spacing.x = unit(10, "pt")
  )
tmp <- ggplot_gtable(ggplot_build(legend_plot))
leg <- which(sapply(tmp$grobs, function(x) x$name) == "guide-box")
legend <- tmp$grobs[[leg]]

# Theme
base_theme <- theme_classic() +
  theme(
    axis.title.y = element_text(size = 12),
    plot.margin = margin(5, 15, 5, 5)
  )

# Plot generator
make_plot <- function(df) {
  ggplot(df, aes(x = iteration, y = mse, color = label)) +
    geom_line(size = 1) +
    scale_color_manual(values = colors) +
    labs(x = "SGD iterates", y = TeX("$\\bf{E}[|\\theta^*-\\theta_t|^2]$")) +
    base_theme +
    theme(legend.position = "none")
}

# Plot 1: Iterations 1 to 100
g1 <- grid.arrange(
  legend,
  make_plot(df_1),
  ncol = 1,
  heights = c(0.2, 1)
)
ggsave("section_c_4_figure_1.png", g1, width = 10, height = 5, dpi = 300)

# Plot 2: Iterations 9900 onwards
g2 <- grid.arrange(
  legend,
  make_plot(df_2),
  ncol = 1,
  heights = c(0.2, 1)
)
ggsave("section_c_4_figure_2.png", g2, width = 10, height = 5, dpi = 300)


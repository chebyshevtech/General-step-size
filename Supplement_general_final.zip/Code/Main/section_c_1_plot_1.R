# Seeding
set.seed(1729)

# Loading the functions file
source("./Functions/Functions.R")

# Loading libraries
library(viridis)
library(ggplot2)
library(dplyr)
library(latex2exp)
library(gridExtra)
library(grid)

# Defining necessary parameters
n <- 10^4
theta.init <- c(0, 0)
theta.true <- c(2, -3)

# SGD runs for constant learning rates
thetas.0.01 <- sgd.lr.sched.multiple(num.iterations, theta.0, theta.true, sd=1, rep(0.01, n))
thetas.0.05 <- sgd.lr.sched.multiple(num.iterations, theta.0, theta.true, sd=1, rep(0.05, n))
thetas.0.1 <- sgd.lr.sched.multiple(num.iterations, theta.0, theta.true, sd=1, rep(0.1, n))

# Calculating the MSE and SE SD for the SGD runs
mse.se.sd.0.01 <- calculate.mse.se.sd(thetas.0.01, theta.true)
mse.se.sd.0.05 <- calculate.mse.se.sd(thetas.0.05, theta.true)
mse.se.sd.0.1 <- calculate.mse.se.sd(thetas.0.1, theta.true)

# Create data frames for each learning rate
df_0.1 <- create_plot_data(mse.se.sd.0.1, "η=0.1")[1:n,]
df_0.05 <- create_plot_data(mse.se.sd.0.05, "η=0.05")[1:n,]
df_0.01 <- create_plot_data(mse.se.sd.0.01, "η=0.01")[1:n,]

# Create data frames for SE SD plots
df_0.1_se_sd  <- create_plot_data_se_sd(mse.se.sd.0.1,  "η=0.1")[1:n, ]
df_0.05_se_sd <- create_plot_data_se_sd(mse.se.sd.0.05, "η=0.05")[1:n, ]
df_0.01_se_sd <- create_plot_data_se_sd(mse.se.sd.0.01, "η=0.01")[1:n, ]

# Filter for later start
df_0.1 <- df_0.1 %>% filter(iteration >= 100)
df_0.05 <- df_0.05 %>% filter(iteration >= 100)
df_0.01 <- df_0.01 %>% filter(iteration >= 500)

df_0.1_se_sd  <- df_0.1_se_sd  %>% filter(iteration >= 9900)
df_0.05_se_sd <- df_0.05_se_sd %>% filter(iteration >= 9900)
df_0.01_se_sd <- df_0.01_se_sd %>% filter(iteration >= 9900)

# Define colors based on viridis turbo palette
colors <- viridis::viridis(3, option = "turbo")
names(colors) <- c("\U03B7=0.1", "\U03B7=0.05", "\U03B7=0.01")

# Create a base theme for consistent styling across panels
base_theme <- theme_classic() +
  theme(axis.title.y = element_text(size = 12),
        plot.margin = margin(5, 15, 5, 5))

# Create individual plots
plot_0.1 <- ggplot(df_0.1, aes(x = iteration)) +
  geom_line(aes(y = mse), color = colors[1]) +
  geom_ribbon(aes(ymin = lower, ymax = upper), fill = colors[1], alpha = 0.2) +
  labs(x = "", y = TeX("$\\bf{E}[|\\theta^*-\\theta_t|^2]$")) +
  base_theme

plot_0.05 <- ggplot(df_0.05, aes(x = iteration)) +
  geom_line(aes(y = mse), color = colors[2]) +
  geom_ribbon(aes(ymin = lower, ymax = upper), fill = colors[2], alpha = 0.2) +
  labs(x = "SGD iterates", y = "") +
  base_theme

plot_0.01 <- ggplot(df_0.01, aes(x = iteration)) +
  geom_line(aes(y = mse), color = colors[3]) +
  geom_ribbon(aes(ymin = lower, ymax = upper), fill = colors[3], alpha = 0.2) +
  labs(x = "SGD iterates", y = "") +
  base_theme

# Create legend
legend_data <- data.frame(
  x = rep(1, 3),
  y = 1:3,
  label = names(colors)
)

legend_plot <- ggplot(legend_data, aes(x = x, y = y, color = label)) +
  geom_point() +
  scale_color_manual(
    values = colors, 
    name = "Learning Rate",
    breaks = names(colors),
    guide = guide_legend(ncol = 3)  # horizontal legend layout
  ) +
  theme_void() +
  theme(
    legend.position = "bottom",
    legend.text = element_text(size = 9),
    legend.spacing.x = unit(10, "pt")
  )

# Extract just the legend
tmp <- ggplot_gtable(ggplot_build(legend_plot))
leg <- which(sapply(tmp$grobs, function(x) x$name) == "guide-box")
legend <- tmp$grobs[[leg]]

# Arrange plots and legend
grid_layout <- grid.arrange(
  legend,
  arrangeGrob(plot_0.1, plot_0.05, plot_0.01, ncol = 3),
  ncol = 1,
  heights = c(0.2, 1)
)

# Save plot with landscape aspect ratio
ggsave("section_c_1_figure_1.png", grid_layout, width = 10, height = 4, dpi = 300)

# Create individual plots for finding SE SD cyclical behavior
plot_0.1_se_sd <- ggplot(df_0.1_se_sd, aes(x = iteration)) +
  geom_line(aes(y = se_sd), color = colors[1]) +
  labs(x = "", y = TeX("$sd(\\bf{E}[|\\theta^*-\\theta_t|^2])$")) +
  base_theme

plot_0.05_se_sd <- ggplot(df_0.05_se_sd, aes(x = iteration)) +
  geom_line(aes(y = se_sd), color = colors[2]) +
  labs(x = "", y = TeX("")) +
  base_theme

plot_0.01_se_sd <- ggplot(df_0.01_se_sd, aes(x = iteration)) +
  geom_line(aes(y = se_sd), color = colors[3]) +
  labs(x = "", y = TeX("")) +
  base_theme

# Arrange plots and legend
grid_layout <- grid.arrange(
  legend,
  arrangeGrob(plot_0.1_se_sd, plot_0.05_se_sd, plot_0.01_se_sd, ncol = 3),
  ncol = 1,
  heights = c(0.2, 1)
)

# Save plot with landscape aspect ratio
ggsave("section_3_3_figure_3.png", grid_layout, width = 10, height = 4, dpi = 300)
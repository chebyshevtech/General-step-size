# Seeding
set.seed(1729)

# Loading the functions file
source("./Functions/Functions.R")

# Loading libraries
library(viridis)
library(ggplot2)
library(dplyr)
library(latex2exp)
library(gridExtra)
library(grid)

# Defining necessary parameters
n <- 10^4
period <- 3
cos.sched <- 1 + cos(2*pi*my.seq/period)
theta.init <- c(0, 0)
theta.true <- c(2, -3)

# SGD runs for consine learning rates
thetas.cos.0.1 <- sgd.lr.sched.multiple(num.iterations, theta.0, theta.true, sd=1, 0.1*cos.sched)
thetas.cos.0.05 <- sgd.lr.sched.multiple(num.iterations, theta.0, theta.true, sd=1, 0.05*cos.sched)
thetas.cos.0.01 <- sgd.lr.sched.multiple(num.iterations, theta.0, theta.true, sd=1, 0.01*cos.sched)

# Calculating the MSE and SE SD for the SGD runs
mse.se.sd.cos.0.1 <- calculate.mse.se.sd(thetas.cos.0.1, theta.true)
mse.se.sd.cos.0.05 <- calculate.mse.se.sd(thetas.cos.0.05, theta.true)
mse.se.sd.cos.0.01 <- calculate.mse.se.sd(thetas.cos.0.01, theta.true)

# Create data frames for cosine learning rates
df_cos_0.1  <- create_plot_data(mse.se.sd.cos.0.1,  "0.1·(1+cos(2πt⁄3))")[1:n, ]
df_cos_0.05 <- create_plot_data(mse.se.sd.cos.0.05, "0.05·(1+cos(2πt⁄3))")[1:n, ]
df_cos_0.01 <- create_plot_data(mse.se.sd.cos.0.01, "0.01·(1+cos(2πt⁄3))")[1:n, ]

# Create data frames for SE SD plots
df_cos_0.1_se_sd  <- create_plot_data_se_sd(mse.se.sd.cos.0.1,  "0.1·(1+cos(2πt⁄3))")[1:n, ]
df_cos_0.05_se_sd <- create_plot_data_se_sd(mse.se.sd.cos.0.05, "0.05·(1+cos(2πt⁄3))")[1:n, ]
df_cos_0.01_se_sd <- create_plot_data_se_sd(mse.se.sd.cos.0.01, "0.01·(1+cos(2πt⁄3))")[1:n, ]

# Filter for later start
df_cos_0.1  <- df_cos_0.1  %>% filter(iteration >= 500)
df_cos_0.05 <- df_cos_0.05 %>% filter(iteration >= 500)
df_cos_0.01 <- df_cos_0.01 %>% filter(iteration >= 500)

df_cos_0.1_se_sd  <- df_cos_0.1_se_sd  %>% filter(iteration >= 9900)
df_cos_0.05_se_sd <- df_cos_0.05_se_sd %>% filter(iteration >= 9900)
df_cos_0.01_se_sd <- df_cos_0.01_se_sd %>% filter(iteration >= 9900)

# Define colors based on viridis turbo palette for cosine
colors_cosine <- viridis::viridis(3, option = "turbo")
names(colors_cosine) <- c(
  "0.1·(1+cos(2πt⁄3))",
  "0.05·(1+cos(2πt⁄3))",
  "0.01·(1+cos(2πt⁄3))"
)

# Create a base theme for consistent styling across panels
base_theme <- theme_classic() +
  theme(axis.title.y = element_text(size = 12),
        plot.margin = margin(5, 15, 5, 5))

# Create individual plots
plot_cos_0.1 <- ggplot(df_cos_0.1, aes(x = iteration)) +
  geom_line(aes(y = mse), color = colors_cosine[1]) +
  geom_ribbon(aes(ymin = lower, ymax = upper), fill = colors_cosine[1], alpha = 0.2) +
  labs(x = "SGD iterates", y = TeX("$\\bf{E}[|\\theta^*-\\theta_t|^2]$")) +
  base_theme

plot_cos_0.05 <- ggplot(df_cos_0.05, aes(x = iteration)) +
  geom_line(aes(y = mse), color = colors_cosine[2]) +
  geom_ribbon(aes(ymin = lower, ymax = upper), fill = colors_cosine[2], alpha = 0.2) +
  labs(x = "SGD iterates", y = "") +
  base_theme

plot_cos_0.01 <- ggplot(df_cos_0.01, aes(x = iteration)) +
  geom_line(aes(y = mse), color = colors_cosine[3]) +
  geom_ribbon(aes(ymin = lower, ymax = upper), fill = colors_cosine[3], alpha = 0.2) +
  labs(x = "SGD iterates", y = "") +
  base_theme

# Create legend
legend_data <- data.frame(
  x = rep(1, 3),
  y = 1:3,
  label = names(colors_cosine)
)

legend_plot <- ggplot(legend_data, aes(x = x, y = y, color = label)) +
  geom_point() +
  scale_color_manual(
    values = colors_cosine, 
    name = "Learning Rate Schedule",
    breaks = names(colors_cosine),
    guide = guide_legend(ncol = 3)  # horizontal legend layout
  ) +
  theme_void() +
  theme(
    legend.position = "bottom",
    legend.text = element_text(size = 9),
    legend.spacing.x = unit(10, "pt")
  )

# Extract just the legend
tmp <- ggplot_gtable(ggplot_build(legend_plot))
leg <- which(sapply(tmp$grobs, function(x) x$name) == "guide-box")
legend <- tmp$grobs[[leg]]

# Arrange plots and legend
grid_layout <- grid.arrange(
  legend,
  arrangeGrob(plot_cos_0.1, plot_cos_0.05, plot_cos_0.01, ncol = 3),
  ncol = 1,
  heights = c(0.2, 1)
)

# Save plot with landscape aspect ratio
ggsave("section_3_3_figure_1.png", grid_layout, width = 10, height = 4, dpi = 300)

# Create individual plots for finding SE SD cyclical behavior
plot_cos_0.1_se_sd <- ggplot(df_cos_0.1_se_sd, aes(x = iteration)) +
  geom_line(aes(y = se_sd), color = colors_cosine[1]) +
  labs(x = "", y = TeX("$sd(\\bf{E}[|\\theta^*-\\theta_t|^2])$")) +
  base_theme

plot_cos_0.05_se_sd <- ggplot(df_cos_0.05_se_sd, aes(x = iteration)) +
  geom_line(aes(y = se_sd), color = colors_cosine[2]) +
  labs(x = "", y = TeX("")) +
  base_theme

plot_cos_0.01_se_sd <- ggplot(df_cos_0.01_se_sd, aes(x = iteration)) +
  geom_line(aes(y = se_sd), color = colors_cosine[3]) +
  labs(x = "", y = TeX("")) +
  base_theme

# Arrange plots and legend
grid_layout <- grid.arrange(
  legend,
  arrangeGrob(plot_cos_0.1_se_sd, plot_cos_0.05_se_sd, plot_cos_0.01_se_sd, ncol = 3),
  ncol = 1,
  heights = c(0.2, 1)
)

# Save plot with landscape aspect ratio
ggsave("section_3_3_figure_2.png", grid_layout, width = 10, height = 4, dpi = 300)
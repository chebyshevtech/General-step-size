library(future.apply)
library(progressr)
library(tidyverse)

# Set up parallel processing
ncores <- 5
plan(multisession, workers = ncores)
handlers("txtprogressbar")

# SGD function with constant eta
mse.lr.constant.final.iterate <- function(theta.init, n, sd = 1, eta, theta_true = c(2, -3)) {
  d <- length(theta.init)
  X <- cbind(rep(1, n), replicate(d - 1, rnorm(n)))
  y <- X %*% theta_true + rnorm(n, sd = sd)
  theta <- theta.init

  for (i in seq_len(n)) {
    y_pred   <- sum(X[i,] * theta)
    gradient <- - (y[i] - y_pred) * X[i,]
    theta    <- theta - eta * gradient
  }

  sum((theta - theta_true)^2)
}

# Learning rates to evaluate
eta_list <- seq(0.01, 0.1, by = 0.001)
niter    <- 500
n        <- 10000

# Run simulation with progress bars and safe RNG
results_list <- with_progress({
  p_outer <- progressor(along = eta_list)

  future_lapply(eta_list, future.seed = TRUE, function(eta) {
    p_outer()
    p_inner <- progressor(steps = niter)
    store_mse <- numeric(niter)

    for (iter in seq_len(niter)) {
      store_mse[iter] <- mse.lr.constant.final.iterate(c(0,0), n, sd = 1, eta = eta)
      p_inner()
    }

    data.frame(
      eta = eta,
      mse = mean(store_mse),
      sd  = sd(store_mse)
    )
  })
})

# Combine and augment results
results <- do.call(rbind, results_list)
results$lower <- results$mse - results$sd
results$upper <- results$mse + results$sd

# Save results and plot to a user-defined writable directory
output_dir <- "~/Documents/generalratesgdsims"
write.csv(results, file = file.path(output_dir, "mse_vs_eta.csv"), row.names = FALSE)

# Plot results
p <- ggplot(results, aes(x = eta, y = mse)) +
  geom_ribbon(aes(ymin = lower, ymax = upper), fill = "grey80", alpha = 0.4) +
  geom_line(size = 0.7) +
  scale_x_continuous("Learning rate (η)", expand = expansion(0)) +
  scale_y_continuous(TeX("$\\bf{E}[|\\theta^*-\\theta_t|^2]$"), expand = expansion(0)) +
  theme_minimal(base_size = 10, base_family = "Times") +
  theme(
    panel.grid.major = element_line(size = 0.2, linetype = "dashed"),
    panel.grid.minor = element_blank(),
    panel.background = element_rect(fill = "white", colour = NA),
    panel.border = element_rect(fill = NA, colour = "black", size = 0.5),
    axis.title = element_text(size = 9),
    axis.text = element_text(size = 8),
    axis.ticks = element_line(size = 0.3)
  )

print(p)
ggsave(filename = file.path(output_dir, "section_c_1_figure_2.png"), width = 5, height = 2.5, units = "in")

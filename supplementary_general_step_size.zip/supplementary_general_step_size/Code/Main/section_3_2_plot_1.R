library(future.apply)
library(progressr)
library(tidyverse)
library(latex2exp)

# Set up parallel processing
ncores <- 5
plan(multisession, workers = ncores)
handlers("txtprogressbar")

# Linear decay schedule SGD function
mse.lr.linear.schedule <- function(theta.init, n, sd = 1, theta_true = c(2, -3)) {
  d <- length(theta.init)
  X <- cbind(rep(1, n), replicate(d - 1, rnorm(n)))
  y <- X %*% theta_true + rnorm(n, sd = sd)
  theta <- theta.init

  for (t in seq_len(n)) {
    eta_t <- 0.1 * (n + 1 - t) / n
    y_pred <- sum(X[t, ] * theta)
    gradient <- - (y[t] - y_pred) * X[t, ]
    theta <- theta - eta_t * gradient
  }

  sqrt(sum((theta - theta_true)^2))
}

# Sample sizes to evaluate
n_list <- seq(100, 10^4, 100)
niter <- 500

# Run simulation with progress bars
results_list <- with_progress({
  p_outer <- progressor(along = n_list)

  future_lapply(n_list, future.seed = TRUE, function(n) {
    p_outer()
    store_mse <- numeric(niter)
    p_inner <- progressor(steps = niter)

    for (iter in seq_len(niter)) {
      store_mse[iter] <- mse.lr.linear.schedule(c(0, 0), n, sd = 1)
      p_inner()
    }

    data.frame(
      n = n,
      mse = mean(store_mse),
      sd = sd(store_mse)
    )
  })
})

# Combine and save results
results <- do.call(rbind, results_list)
results$lower <- results$mse - results$sd
results$upper <- results$mse + results$sd

# Write safely to user-defined directory
output_dir <- "~/Documents/generalratesgdsims"
out_csv <- file.path(output_dir, "mse_vs_n_linear_schedule.csv")
write.csv(results, file = out_csv, row.names = FALSE)

# Plot the results
p <- ggplot(results, aes(x = n, y = mse)) +
  geom_ribbon(aes(ymin = lower, ymax = upper), fill = "grey80", alpha = 0.4) +
  geom_line(size = 0.7) +
  scale_x_continuous("Sample size (n)", expand = expansion(0)) +
  scale_y_continuous(TeX("$\\bf{E}[|\\theta^*-\\theta_t|^2]$"), expand = expansion(0)) +
  theme_minimal(base_size = 10, base_family = "Times") +
  theme(
    plot.margin = margin(5, 30, 5, 5),
    panel.grid.major = element_line(size = 0.2, linetype = "dashed"),
    panel.grid.minor = element_blank(),
    panel.background = element_rect(fill = "white", colour = NA),
    panel.border = element_rect(fill = NA, colour = "black", size = 0.5),
    axis.title = element_text(size = 9),
    axis.text = element_text(size = 8),
    axis.ticks = element_line(size = 0.3)
  )

# Save plot
out_plot <- file.path(output_dir, "section_3_2_figure_1.png")
ggsave(filename = out_plot, plot = p, width = 5, height = 2.5, units = "in")

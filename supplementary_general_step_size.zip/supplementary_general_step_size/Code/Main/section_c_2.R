# Seeding
set.seed(1729)

# Loading the functions file
source("./Functions/Functions.R")

# Loading libraries
library(viridis)
library(ggplot2)
library(dplyr)
library(latex2exp)
library(gridExtra)
library(grid)

# Defining necessary parameters
n <- 10^4
my.seq <- seq(n)
beta.505 <- my.seq^(-0.505)
beta.75 <- my.seq^(-0.75)
theta.init <- c(0, 0)
theta.true <- c(2, -3)

# SGD runs for polynomially decaying learning rates
thetas.0.1.0.505 <- sgd.lr.sched.multiple(num.iterations, theta.0, theta.true, sd=1, 0.1*beta.505)
thetas.0.1.0.75 <- sgd.lr.sched.multiple(num.iterations, theta.0, theta.true, sd=1, 0.1*beta.75)
thetas.0.05.0.505 <- sgd.lr.sched.multiple(num.iterations, theta.0, theta.true, sd=1, 0.05*beta.505)
thetas.0.05.0.75 <- sgd.lr.sched.multiple(num.iterations, theta.0, theta.true, sd=1, 0.05*beta.75)

# Calculating the MSE and SE SD for the SGD runs
mse.se.sd.0.1.0.505.cos <- calculate.mse.se.sd(thetas.0.1.0.505, theta.true)
mse.se.sd.0.1.0.75.cos <- calculate.mse.se.sd(thetas.0.1.0.75, theta.true)
mse.se.sd.0.05.0.505.cos <- calculate.mse.se.sd(thetas.0.05.0.505, theta.true)
mse.se.sd.0.05.0.75.cos <- calculate.mse.se.sd(thetas.0.05.0.75, theta.true)

# Limit number of points
n_points <- min(n, 10000)

# Create and filter labeled data for each (η₀, β) combo
df_0.1_0.505 <- create_plot_data(mse.se.sd.0.1.0.505, "\u03B7\u2080=0.1, \u03B2=0.505")[1:n_points, ] %>%
  filter(iteration >= 1000)
df_0.1_0.75  <- create_plot_data(mse.se.sd.0.1.0.75,  "\u03B7\u2080=0.1, \u03B2=0.75")[1:n_points, ] %>%
  filter(iteration >= 5000)
df_0.05_0.505 <- create_plot_data(mse.se.sd.0.05.0.505, "\u03B7\u2080=0.05, \u03B2=0.505")[1:n_points, ] %>%
  filter(iteration >= 4000)
df_0.05_0.75  <- create_plot_data(mse.se.sd.0.05.0.75,  "\u03B7\u2080=0.05, \u03B2=0.75")[1:n_points, ] %>%
  filter(iteration >= 5000)

# Combine all data
plot_data <- bind_rows(df_0.1_0.505, df_0.1_0.75, df_0.05_0.505, df_0.05_0.75)

# Set color mapping
legend_labels <- unique(plot_data$label)
colors <- viridis(length(legend_labels), option = "turbo")
names(colors) <- legend_labels

# Base theme
plot_theme <- theme_classic() +
  theme(
    axis.title = element_text(size = 11),
    axis.text = element_text(size = 9),
    plot.margin = margin(5, 10, 5, 5),
    legend.position = "top",
    legend.title = element_blank(),
    legend.text = element_text(size = 9)
  )

# Generate individual plots for each label
plots <- lapply(split(plot_data, plot_data$label), function(subdata) {
  label <- unique(subdata$label)
  ggplot(subdata, aes(x = iteration, y = mse)) +
    geom_line(color = colors[label]) +
    geom_ribbon(aes(ymin = lower, ymax = upper), fill = colors[label], alpha = 0.2) +
    labs(x = "SGD iterates", y = TeX("$\\bf{E}[|\\theta^*-\\theta_t|^2]$")) +
    theme_classic() +
    theme(
      axis.title = element_text(size = 10),
      axis.text = element_text(size = 8),
      plot.margin = margin(5, 5, 5, 5)
    )
})

# Arrange in 2x2 grid
panel_grid <- arrangeGrob(
  grobs = plots,
  ncol = 2,
  nrow = 2
)

# Create the legend from a dummy ggplot
legend_plot <- ggplot(plot_data, aes(x = iteration, y = mse, color = label, fill = label)) +
  geom_line() +
  scale_color_manual(values = colors) +
  scale_fill_manual(values = colors) +
  theme_void() +
  theme(
    legend.position = "top",
    legend.title = element_blank(),
    legend.text = element_text(size = 9)
  )

tmp <- ggplot_gtable(ggplot_build(legend_plot))
leg <- which(sapply(tmp$grobs, function(x) x$name) == "guide-box")
legend <- tmp$grobs[[leg]]

# Combine legend and grid
final_plot <- grid.arrange(
  legend,
  panel_grid,
  ncol = 1,
  heights = c(0.3, 1)
)

# Save
ggsave("section_c_2_plot_1.png", final_plot, width = 8, height = 5, dpi = 300)
# Seeding
set.seed(1729)

# Loading the functions file
source("./Functions/Functions.R")

# Libraries
library(ggplot2)
library(dplyr)
library(viridis)
library(gridExtra)
library(grid)
library(latex2exp)

# Legend generator
generate_legend <- function(labels, colors) {
  legend_data <- data.frame(x = rep(1, length(labels)), y = seq_along(labels), label = labels)
  legend_plot <- ggplot(legend_data, aes(x = x, y = y, color = label)) +
    geom_point() +
    scale_color_manual(
      values = colors,
      name = "Learning Rate",
      breaks = labels,
      guide = guide_legend(ncol = length(labels))
    ) +
    theme_void() +
    theme(
      legend.position = "bottom",
      legend.text = element_text(size = 9),
      legend.spacing.x = unit(10, "pt")
    )
  tmp <- ggplot_gtable(ggplot_build(legend_plot))
  leg <- which(sapply(tmp$grobs, function(x) x$name) == "guide-box")
  tmp$grobs[[leg]]
}

# Theme
base_theme <- theme_classic() +
  theme(
    axis.title.y = element_text(size = 12),
    plot.margin = margin(5, 15, 5, 5)
  )

# Plot creator
create_panel_plot <- function(dfs, colors, y_labels) {
  plots <- mapply(function(df, color, show_y) {
    ggplot(df, aes(x = iteration)) +
      geom_line(aes(y = mse), color = color) +
      geom_ribbon(aes(ymin = lower, ymax = upper), fill = color, alpha = 0.2) +
      labs(x = "SGD iterates", y = if (show_y) TeX("$\\bf{E}[|\\theta^*-\\theta_t|^2]$") else "") +
      base_theme
  }, dfs, colors, y_labels, SIMPLIFY = FALSE)
  return(plots)
}

# Labels and colors
labels_lin <- c("η₀ = 0.05", "η₀ = 0.1", "η₀ = 0.5")
colors_lin <- viridis(3, option = "turbo")
names(colors_lin) <- labels_lin

# --- Plot 1: Iteration 1 to 100 ---
df_lin_early <- list(
  create_plot_data(mse.se.sd.lin.0.05, labels_lin[1]) %>% filter(iteration >= 1, iteration <= 100),
  create_plot_data(mse.se.sd.lin.0.1,  labels_lin[2]) %>% filter(iteration >= 1, iteration <= 100),
  create_plot_data(mse.se.sd.lin.0.5,  labels_lin[3]) %>% filter(iteration >= 1, iteration <= 100)
)
plots_early <- create_panel_plot(df_lin_early, colors_lin, c(TRUE, FALSE, FALSE))
legend_early <- generate_legend(labels_lin, colors_lin)
g1 <- grid.arrange(legend_early, arrangeGrob(grobs = plots_early, ncol = 3), ncol = 1, heights = c(0.2, 1))
ggsave("section_3_2_figure_2.png", g1, width = 10, height = 4, dpi = 300)

# --- Plot 2: Iteration 500 onwards ---
df_lin_late <- list(
  create_plot_data(mse.se.sd.lin.0.05, labels_lin[1]) %>% filter(iteration >= 500),
  create_plot_data(mse.se.sd.lin.0.1,  labels_lin[2]) %>% filter(iteration >= 500),
  create_plot_data(mse.se.sd.lin.0.5,  labels_lin[3]) %>% filter(iteration >= 500)
)
plots_late <- create_panel_plot(df_lin_late, colors_lin, c(TRUE, FALSE, FALSE))
legend_late <- generate_legend(labels_lin, colors_lin)
g2 <- grid.arrange(legend_late, arrangeGrob(grobs = plots_late, ncol = 3), ncol = 1, heights = c(0.2, 1))
ggsave("section_3_2_figure_3.png", g2, width = 10, height = 4, dpi = 300)
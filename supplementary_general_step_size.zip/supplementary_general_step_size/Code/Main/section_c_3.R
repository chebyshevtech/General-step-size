# Seeding
set.seed(1729)

# Loading the functions file
source("./Functions/Functions.R")

# Libraries
library(ggplot2)
library(dplyr)
library(viridis)
library(gridExtra)
library(grid)
library(latex2exp)

# Defining necessary parameters
n <- 10^4
beta.505 <- my.seq^(-0.505)
beta.75 <- my.seq^(-0.75)
low.odd <- beta.505[seq(1, n, 2)]
high.odd <- beta.75[seq(1, n, 2)]
high.even <- beta.75[seq(2, n, 2)]
cos.even <- cos.sched[seq(2, n, 2)]
mix.low.const <- as.vector(rbind(low.odd, rep(1, n/2)))
mix.low.high <- as.vector(rbind(low.odd, high.even))
mix.high.const <- as.vector(rbind(high.odd, rep(1, n/2)))
theta.init <- c(0, 0)
theta.true <- c(2, -3)

# SGD runs for alternating polynomial schedules
thetas.0.1.low.const <- sgd.lr.sched.multiple(num.iterations, theta.0, theta.true, sd=1, 0.1*mix.low.const)
thetas.0.1.low.high <- sgd.lr.sched.multiple(num.iterations, theta.0, theta.true, sd=1, 0.1*mix.low.high)
thetas.0.1.high.const <- sgd.lr.sched.multiple(num.iterations, theta.0, theta.true, sd=1, 0.1*mix.high.const)
thetas.0.05.low.const <- sgd.lr.sched.multiple(num.iterations, theta.0, theta.true, sd=1, 0.05*mix.low.const)
thetas.0.05.low.high <- sgd.lr.sched.multiple(num.iterations, theta.0, theta.true, sd=1, 0.05*mix.low.high)
thetas.0.05.high.const <- sgd.lr.sched.multiple(num.iterations, theta.0, theta.true, sd=1, 0.05*mix.high.const)
thetas.0.1.0.01.low <- sgd.lr.sched.multiple(num.iterations, theta.0, theta.true, sd=1, rates.0.1.0.01*beta.505)
thetas.0.2.0.02.low <- sgd.lr.sched.multiple(num.iterations, theta.0, theta.true, sd=1, 2*rates.0.1.0.01*beta.505)

# Calculating the MSE and SE SD for the SGD runs
mse.se.sd.0.1.low.const <- calculate.mse.se.sd(thetas.0.1.low.const, theta.true)
mse.se.sd.0.1.low.high <- calculate.mse.se.sd(thetas.0.1.low.high, theta.true)
mse.se.sd.0.1.high.const <- calculate.mse.se.sd(thetas.0.1.high.const, theta.true)
mse.se.sd.0.05.low.const <- calculate.mse.se.sd(thetas.0.05.low.const, theta.true)
mse.se.sd.0.05.low.high <- calculate.mse.se.sd(thetas.0.05.low.high, theta.true)
mse.se.sd.0.05.high.const <- calculate.mse.se.sd(thetas.0.05.high.const, theta.true)
mse.se.sd.0.1.0.01.low <- calculate.mse.se.sd(thetas.0.1.0.01.low, theta.true)
mse.se.sd.0.2.0.02.low <- calculate.mse.se.sd(thetas.0.2.0.02.low, theta.true)

# Themed legend generator
generate_legend <- function(labels, colors) {
  legend_data <- data.frame(x = rep(1, length(labels)), y = seq_along(labels), label = labels)
  legend_plot <- ggplot(legend_data, aes(x = x, y = y, color = label)) +
    geom_point() +
    scale_color_manual(
      values = colors,
      name = "Schedule",
      breaks = labels,
      guide = guide_legend(ncol = length(labels))
    ) +
    theme_void() +
    theme(
      legend.position = "bottom",
      legend.text = element_text(size = 9),
      legend.spacing.x = unit(10, "pt")
    )
  tmp <- ggplot_gtable(ggplot_build(legend_plot))
  leg <- which(sapply(tmp$grobs, function(x) x$name) == "guide-box")
  tmp$grobs[[leg]]
}

# Standard theme
base_theme <- theme_classic() +
  theme(axis.title.y = element_text(size = 12),
        plot.margin = margin(5, 15, 5, 5))

# Plot creation
create_panel_plot <- function(dfs, colors, y_labels) {
  plots <- mapply(function(df, color, show_y) {
    ggplot(df, aes(x = iteration)) +
      geom_line(aes(y = mse), color = color) +
      geom_ribbon(aes(ymin = lower, ymax = upper), fill = color, alpha = 0.2) +
      labs(x = "SGD iterates", y = if (show_y) TeX("$\\bf{E}[|\\theta^*-\\theta_t|^2]$") else "") +
      base_theme
  }, dfs, colors, y_labels, SIMPLIFY = FALSE)
  return(plots)
}

# --- ETA 0.1 ---
filter_starts_eta01 <- c(500, 1000, 500)
eta01_raw <- list(
  list(data = mse.se.sd.0.1.low.const, label = "β = (0.505, 0)"),
  list(data = mse.se.sd.0.1.low.high, label = "β = (0.505, 0.75)"),
  list(data = mse.se.sd.0.1.high.const, label = "β = (0.75, 0)")
)
df_eta01 <- mapply(function(x, start) create_plot_data(x$data, x$label) %>% filter(iteration >= start),
                   eta01_raw, filter_starts_eta01, SIMPLIFY = FALSE)
labels_eta01 <- sapply(eta01_raw, `[[`, "label")
colors_eta01 <- viridis(3, option = "turbo")
names(colors_eta01) <- labels_eta01
plots_eta01 <- create_panel_plot(df_eta01, colors_eta01, c(TRUE, FALSE, FALSE))
legend_eta01 <- generate_legend(labels_eta01, colors_eta01)
g1 <- grid.arrange(legend_eta01, arrangeGrob(grobs = plots_eta01, ncol = 3), ncol = 1, heights = c(0.2, 1))
ggsave("Alternating rates eta 0.1.png", g1, width = 10, height = 4, dpi = 300)

# --- ETA 0.05 ---
filter_starts_eta005 <- c(500, 1000, 500)
eta005_raw <- list(
  list(data = mse.se.sd.0.05.low.const, label = "β = (0.505, 0)"),
  list(data = mse.se.sd.0.05.low.high, label = "β = (0.505, 0.75)"),
  list(data = mse.se.sd.0.05.high.const, label = "β = (0.75, 0)")
)
df_eta005 <- mapply(function(x, start) create_plot_data(x$data, x$label) %>% filter(iteration >= start),
                    eta005_raw, filter_starts_eta005, SIMPLIFY = FALSE)
labels_eta005 <- sapply(eta005_raw, `[[`, "label")
colors_eta005 <- viridis(3, option = "turbo")
names(colors_eta005) <- labels_eta005
plots_eta005 <- create_panel_plot(df_eta005, colors_eta005, c(TRUE, FALSE, FALSE))
legend_eta005 <- generate_legend(labels_eta005, colors_eta005)
g2 <- grid.arrange(legend_eta005, arrangeGrob(grobs = plots_eta005, ncol = 3), ncol = 1, heights = c(0.2, 1))
ggsave("Alternating rates eta 0.05.png", g2, width = 10, height = 4, dpi = 300)

# --- ETA Comparison ---
filter_start_etas <- c(2000, 2000)
etas_list <- list(
  list(data = mse.se.sd.0.1.0.01.low, label = "η₀ = 0.1"),
  list(data = mse.se.sd.0.2.0.02.low, label = "η₀ = 0.2")
)
df_etas <- mapply(function(x, start) create_plot_data(x$data, x$label) %>% filter(iteration >= start),
                  etas_list, filter_start_etas, SIMPLIFY = FALSE)
labels_etas <- sapply(etas_list, `[[`, "label")
colors_etas <- viridis(2, option = "turbo")
names(colors_etas) <- labels_etas
plots_etas <- create_panel_plot(df_etas, colors_etas, c(TRUE, FALSE))
legend_etas <- generate_legend(labels_etas, colors_etas)
g3 <- grid.arrange(legend_etas, arrangeGrob(grobs = plots_etas, ncol = 2), ncol = 1, heights = c(0.2, 1))
ggsave("Alternating rates etas.png", g3, width = 7, height = 4, dpi = 300)

# --- Alternating Cosine Schedules ---
filter_start_cosines <- c(25, 25)
cosine_list <- list(
  list(data = mse.se.sd.0.1.low.cos, label = "(β = 0.505, 1+cos(2πt⁄3))"),
  list(data = mse.se.sd.0.1.high.cos, label = "(β = 0.75, 1+cos(2πt⁄3))")
)
df_cosine <- mapply(function(x, start) create_plot_data(x$data, x$label) %>% filter(iteration >= start),
                    cosine_list, filter_start_cosines, SIMPLIFY = FALSE)
labels_cosine <- sapply(cosine_list, `[[`, "label")
colors_cosine <- viridis(2, option = "turbo")
names(colors_cosine) <- labels_cosine
plots_cosine <- create_panel_plot(df_cosine, colors_cosine, c(TRUE, FALSE))
legend_cosine <- generate_legend(labels_cosine, colors_cosine)
g4 <- grid.arrange(legend_cosine, arrangeGrob(grobs = plots_cosine, ncol = 2), ncol = 1, heights = c(0.2, 1))
ggsave("Alternating poly cosine schedules.png", g4, width = 7, height = 4, dpi = 300)
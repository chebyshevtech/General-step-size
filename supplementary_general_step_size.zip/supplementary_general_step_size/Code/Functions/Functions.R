# Loading libraries
library(tidyverse)
library(MASS)
library(matrixStats)
library(comprehenr)
library(latex2exp)
library(pbapply)
library(parallel)

# SGD function
sgd.lr.sched <- function(X, y, theta.init, epochs = 1, batch.size = 1, sched) {
  theta <- theta.init
  thetas <- matrix(theta, ncol = 1)
  
  for (k in 1:epochs) {
    indices <- sample(length(y))
    X <- X[indices, , drop = FALSE]
    y <- y[indices]
    
    for (i in seq(1, length(y), batch.size)) {
      end.idx <- min(i + batch.size - 1, length(y))
      X.batch <- X[i:end.idx, , drop = FALSE]
      y.batch <- y[i:end.idx]
      
      t.time <- (k - 1) * (length(y) / batch.size) + (i - 1) / batch.size + 1
      
      y.pred <- rowSums(X.batch * rep(theta, each = nrow(X.batch)))
      residuals <- y.batch - y.pred
      gradient <- -colSums(X.batch * residuals)
      
      theta <- theta - sched[t.time] * gradient
      thetas <- cbind(thetas, theta)
    }
  }
  
  return(thetas)
}

# Multiple iterations with Windows-compatible parallelism
sgd.lr.sched.multiple <- function(n.iter, theta.init, theta.true, sd = 1, sched) {
  n <- length(sched)
  d <- length(theta.init)
  
  run_single_iter <- function(iter) {
    X <- cbind(1, replicate(d - 1, rnorm(n)))
    y <- as.vector(X %*% theta.true + rnorm(n, sd = sd))
    sgd.lr.sched(X, y, theta.init, sched = sched)[, -1]
  }
  
  # Use parLapply for Windows-safe parallelism
  num.cores <- max(1, detectCores() - 1)
  cl <- makeCluster(num.cores)
  clusterExport(cl, varlist = c("theta.init", "theta.true", "sd", "sched", "n", "d", "sgd.lr.sched"), envir = environment())
  
  results <- pbapply::pblapply(
    X = 1:n.iter,
    FUN = run_single_iter,
    cl = cl  # Use the cluster for parallel computation
  )
  stopCluster(cl)
  
  thetas.list <- array(unlist(results), dim = c(d, n, n.iter))
  thetas.list <- aperm(thetas.list, c(3, 1, 2))  # [n.iter, d, n]
  
  return(thetas.list)
}

# MSE and SE SD calculation
calculate.mse.se.sd <- function(thetas.array, theta.true) {
  # thetas.array: [n.iter, d, n]
  # theta.true: vector of length d (true parameter values)
  
  # Compute squared error: ||theta_est - theta_true||^2 for each [iteration, step]
  squared.errors <- apply(thetas.array, c(1, 3), function(params) {
    sum((params - theta.true)^2)
  })
  
  # SE SD and MSE across iterations, per time step
  se.sd <- apply(squared.errors, 2, sd)
  mse <- colMeans(squared.errors)
  
  return(list(se.sd = se.sd, mse = mse))
}

# Creating plot data for the MSE with SE SD shadows
create_plot_data <- function(mse_se_sd, label_name) {
  iterations <- seq_len(length(mse_se_sd[[1]]))
  mse <- mse_se_sd[[1]]
  se_sd <- mse_se_sd[[2]]
  
  return(data.frame(
    iteration = iterations,
    mse = mse,
    upper = mse + se_sd,
    lower = pmax(mse - se_sd, 1e-10), # Prevent negative values when plotting log
    label = label_name
  ))
}

# Creating SE SD plot data
create_plot_data_se_sd <- function(mse_se_sd, label_name) {
  iterations <- seq_len(length(mse_se_sd[[1]]))
  se_sd <- mse_se_sd[[2]]
  
  return(data.frame(
    iteration = iterations,
    se_sd = se_sd,
    label = label_name
  ))
}